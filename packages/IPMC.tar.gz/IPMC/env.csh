#  This file is part of the IPMC project. It is subject to the license terms in
#  the LICENSE.txt file found in the top-level directory of this distribution
#  and at https://confluence.slac.stanford.edu/display/ppareg/LICENSE.html. No
#  part of the IPMC project, including this file, may be copied, modified,
#  propagated, or distributed except according to the terms contained in the
#  LICENSE.txt file.

# Csh environment setup for using the IPMC command wrappers
#
# This file is meant to be sourced from a shell

# csh trickery to get the full path to the parent directory for a sourced file
set _sourced=`/usr/sbin/lsof +p $$ | grep -oE /.\*env.csh`
set _ipmcRoot=`dirname ${_sourced}`
set _ipmcRoot=`cd ${_ipmcRoot} >& /dev/null && pwd`

if (${?HOSTTYPE} == 0) then
  setenv HOSTTYPE
endif
switch (${HOSTTYPE})
case x86_64*:
  set _libPath=${_ipmcRoot}/lib64
  set _binPath=${_ipmcRoot}/bin/x86_64-linux-dbg
  breaksw
default:
  set _libPath=${_ipmcRoot}/lib
  set _binPath=${_ipmcRoot}/bin/i386-linux-dbg
  breaksw
endsw

if (${?LD_LIBRARY_PATH} != 0) then
  setenv LD_LIBRARY_PATH ${LD_LIBRARY_PATH}:${_libPath}
else
  setenv LD_LIBRARY_PATH ${_libPath}
endif
setenv PATH ${PATH}:${_binPath}

unset _binPath
unset _libPath
unset _ipmcRoot
unset _sourced
